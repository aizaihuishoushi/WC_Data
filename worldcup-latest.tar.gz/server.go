package main

import (
	"flag"
	"fmt"
	"io"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

// ==================== 配置你的 API Token ====================
// 从 football-data.org 获取免费 token: https://www.football-data.org/register
// 将下面的 your_token_here 替换为你的实际 token
const API_KEY = "your_token_here"
// ============================================================

// 是否强制使用模拟数据（true=强制用假数据，false=尝试真实API）
const FORCE_MOCK = false

func main() {
	port := flag.Int("port", 8080, "HTTP server port")
	flag.Parse()

	dir, err := filepath.Abs(filepath.Dir(os.Args[0]))
	if err != nil {
		log.Fatal(err)
	}

	distDir := filepath.Join(dir, "dist")
	if _, err := os.Stat(distDir); os.IsNotExist(err) {
		// 如果 dist 不存在，尝试从当前目录找
		distDir = "./dist"
	}

	fmt.Printf("\n========================================\n")
	fmt.Printf("  世界杯信息服务器\n")
	fmt.Printf("  静态目录: %s\n", distDir)
	fmt.Printf("  API Token: ")
	if API_KEY == "your_token_here" || API_KEY == "" {
		fmt.Printf("未配置 (使用模拟数据)\n")
	} else {
		fmt.Printf("已配置\n")
	}
	fmt.Printf("========================================\n\n")
	fmt.Printf("🚀 服务器已启动，请打开浏览器访问: http://localhost:%d\n", *port)
	fmt.Printf("📝 按 Ctrl+C 停止服务器\n\n")

	// API 代理路由
	http.HandleFunc("/api/matches", handleMatchesAPI)

	// 静态文件
	fs := http.FileServer(http.Dir(distDir))
	http.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		// SPA 路由支持：非根路径的请求也返回 index.html
		if r.URL.Path != "/" && !strings.Contains(r.URL.Path, ".") {
			http.ServeFile(w, r, filepath.Join(distDir, "index.html"))
			return
		}
		fs.ServeHTTP(w, r)
	})

	log.Fatal(http.ListenAndServe(fmt.Sprintf(":%d", *port), nil))
}

func handleMatchesAPI(w http.ResponseWriter, r *http.Request) {
	// 允许跨域
	w.Header().Set("Access-Control-Allow-Origin", "*")
	w.Header().Set("Access-Control-Allow-Methods", "GET, OPTIONS")
	w.Header().Set("Access-Control-Allow-Headers", "Content-Type, Authorization")

	if r.Method == "OPTIONS" {
		w.WriteHeader(http.StatusOK)
		return
	}

	// 强制使用模拟数据
	if FORCE_MOCK {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(mockData))
		return
	}

	// Token 未配置，返回模拟数据
	if API_KEY == "" || API_KEY == "your_token_here" {
		fmt.Println("[API] Token 未配置，返回模拟数据")
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(mockData))
		return
	}

	// 请求真实 API
	fmt.Println("[API] 正在请求 football-data.org...")
	client := &http.Client{}
	req, err := http.NewRequest("GET", "https://api.football-data.org/v4/competitions/WC/matches", nil)
	if err != nil {
		fmt.Println("[API] 创建请求失败:", err)
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(mockData))
		return
	}

	req.Header.Set("X-Auth-Token", API_KEY)
	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("[API] 请求失败:", err)
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(mockData))
		return
	}
	defer resp.Body.Close()

	fmt.Println("[API] 响应状态:", resp.Status)

	if resp.StatusCode != http.StatusOK {
		fmt.Println("[API] 响应异常，返回模拟数据")
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(mockData))
		return
	}

	body, err := io.ReadAll(resp.Body)
	if err != nil {
		fmt.Println("[API] 读取响应失败:", err)
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(mockData))
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.Write(body)
}

// 备用的模拟数据（JSON 格式，2026年世界杯12个小组，48支球队）
const mockData = `{
  "count": 36,
  "matches": [
    {"id": 1,"utcDate": "2026-06-14T18:00:00Z","status": "FINISHED","group": "GROUP_A","stage": "FIRST_ROUND","homeTeam": {"shortName": "Mexico","name": "Mexico"},"awayTeam": {"shortName": "Canada","name": "Canada"},"score": {"fullTime": {"home": 2, "away": 1}},"venue": "Estadio Azteca, Mexico City"},
    {"id": 2,"utcDate": "2026-06-14T21:00:00Z","status": "FINISHED","group": "GROUP_A","stage": "FIRST_ROUND","homeTeam": {"shortName": "Uruguay","name": "Uruguay"},"awayTeam": {"shortName": "Korea Republic","name": "Korea Republic"},"score": {"fullTime": {"home": 1, "away": 0}},"venue": "Estadio Azteca, Mexico City"},
    {"id": 3,"utcDate": "2026-06-15T18:00:00Z","status": "FINISHED","group": "GROUP_B","stage": "FIRST_ROUND","homeTeam": {"shortName": "USA","name": "United States"},"awayTeam": {"shortName": "Ecuador","name": "Ecuador"},"score": {"fullTime": {"home": 2, "away": 0}},"venue": "MetLife Stadium, New York"},
    {"id": 4,"utcDate": "2026-06-15T21:00:00Z","status": "FINISHED","group": "GROUP_B","stage": "FIRST_ROUND","homeTeam": {"shortName": "Portugal","name": "Portugal"},"awayTeam": {"shortName": "Ghana","name": "Ghana"},"score": {"fullTime": {"home": 3, "away": 1}},"venue": "MetLife Stadium, New York"},
    {"id": 5,"utcDate": "2026-06-16T18:00:00Z","status": "FINISHED","group": "GROUP_C","stage": "FIRST_ROUND","homeTeam": {"shortName": "Argentina","name": "Argentina"},"awayTeam": {"shortName": "Saudi Arabia","name": "Saudi Arabia"},"score": {"fullTime": {"home": 3, "away": 0}},"venue": "AT&T Stadium, Dallas"},
    {"id": 6,"utcDate": "2026-06-16T21:00:00Z","status": "FINISHED","group": "GROUP_C","stage": "FIRST_ROUND","homeTeam": {"shortName": "Netherlands","name": "Netherlands"},"awayTeam": {"shortName": "Senegal","name": "Senegal"},"score": {"fullTime": {"home": 2, "away": 2}},"venue": "AT&T Stadium, Dallas"},
    {"id": 7,"utcDate": "2026-06-17T18:00:00Z","status": "FINISHED","group": "GROUP_D","stage": "FIRST_ROUND","homeTeam": {"shortName": "France","name": "France"},"awayTeam": {"shortName": "Australia","name": "Australia"},"score": {"fullTime": {"home": 4, "away": 1}},"venue": "Lincoln Financial Field, Philadelphia"},
    {"id": 8,"utcDate": "2026-06-17T21:00:00Z","status": "FINISHED","group": "GROUP_D","stage": "FIRST_ROUND","homeTeam": {"shortName": "Denmark","name": "Denmark"},"awayTeam": {"shortName": "Tunisia","name": "Tunisia"},"score": {"fullTime": {"home": 2, "away": 0}},"venue": "Lincoln Financial Field, Philadelphia"},
    {"id": 9,"utcDate": "2026-06-18T18:00:00Z","status": "IN_PLAY","group": "GROUP_E","stage": "FIRST_ROUND","homeTeam": {"shortName": "Germany","name": "Germany"},"awayTeam": {"shortName": "Japan","name": "Japan"},"score": {"fullTime": {"home": 1, "away": 2}},"venue": "BC Place, Vancouver"},
    {"id": 10,"utcDate": "2026-06-18T21:00:00Z","status": "SCHEDULED","group": "GROUP_E","stage": "FIRST_ROUND","homeTeam": {"shortName": "Spain","name": "Spain"},"awayTeam": {"shortName": "Costa Rica","name": "Costa Rica"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "BC Place, Vancouver"},
    {"id": 11,"utcDate": "2026-06-19T18:00:00Z","status": "FINISHED","group": "GROUP_F","stage": "FIRST_ROUND","homeTeam": {"shortName": "Brazil","name": "Brazil"},"awayTeam": {"shortName": "Switzerland","name": "Switzerland"},"score": {"fullTime": {"home": 2, "away": 0}},"venue": "SoFi Stadium, Los Angeles"},
    {"id": 12,"utcDate": "2026-06-19T21:00:00Z","status": "IN_PLAY","group": "GROUP_F","stage": "FIRST_ROUND","homeTeam": {"shortName": "Colombia","name": "Colombia"},"awayTeam": {"shortName": "Morocco","name": "Morocco"},"score": {"fullTime": {"home": 1, "away": 1}},"venue": "SoFi Stadium, Los Angeles"},
    {"id": 13,"utcDate": "2026-06-20T18:00:00Z","status": "FINISHED","group": "GROUP_G","stage": "FIRST_ROUND","homeTeam": {"shortName": "England","name": "England"},"awayTeam": {"shortName": "IR Iran","name": "IR Iran"},"score": {"fullTime": {"home": 3, "away": 1}},"venue": "NRG Stadium, Houston"},
    {"id": 14,"utcDate": "2026-06-20T21:00:00Z","status": "SCHEDULED","group": "GROUP_G","stage": "FIRST_ROUND","homeTeam": {"shortName": "Belgium","name": "Belgium"},"awayTeam": {"shortName": "Croatia","name": "Croatia"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "NRG Stadium, Houston"},
    {"id": 15,"utcDate": "2026-06-21T18:00:00Z","status": "FINISHED","group": "GROUP_H","stage": "FIRST_ROUND","homeTeam": {"shortName": "Italy","name": "Italy"},"awayTeam": {"shortName": "Panama","name": "Panama"},"score": {"fullTime": {"home": 3, "away": 0}},"venue": "Mercedes-Benz Stadium, Atlanta"},
    {"id": 16,"utcDate": "2026-06-21T21:00:00Z","status": "FINISHED","group": "GROUP_H","stage": "FIRST_ROUND","homeTeam": {"shortName": "Chile","name": "Chile"},"awayTeam": {"shortName": "Cameroon","name": "Cameroon"},"score": {"fullTime": {"home": 1, "away": 0}},"venue": "Mercedes-Benz Stadium, Atlanta"},
    {"id": 17,"utcDate": "2026-06-22T18:00:00Z","status": "SCHEDULED","group": "GROUP_I","stage": "FIRST_ROUND","homeTeam": {"shortName": "Norway","name": "Norway"},"awayTeam": {"shortName": "New Zealand","name": "New Zealand"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "Lumen Field, Seattle"},
    {"id": 18,"utcDate": "2026-06-22T21:00:00Z","status": "SCHEDULED","group": "GROUP_I","stage": "FIRST_ROUND","homeTeam": {"shortName": "Morocco","name": "Morocco"},"awayTeam": {"shortName": "Egypt","name": "Egypt"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "Lumen Field, Seattle"},
    {"id": 19,"utcDate": "2026-06-23T18:00:00Z","status": "SCHEDULED","group": "GROUP_J","stage": "FIRST_ROUND","homeTeam": {"shortName": "Canada","name": "Canada"},"awayTeam": {"shortName": "South Korea","name": "South Korea"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "BMO Field, Toronto"},
    {"id": 20,"utcDate": "2026-06-23T21:00:00Z","status": "SCHEDULED","group": "GROUP_J","stage": "FIRST_ROUND","homeTeam": {"shortName": "Serbia","name": "Serbia"},"awayTeam": {"shortName": "Ecuador","name": "Ecuador"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "BMO Field, Toronto"},
    {"id": 21,"utcDate": "2026-06-24T18:00:00Z","status": "SCHEDULED","group": "GROUP_K","stage": "FIRST_ROUND","homeTeam": {"shortName": "Sweden","name": "Sweden"},"awayTeam": {"shortName": "Ivory Coast","name": "Ivory Coast"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "Commonwealth Stadium, Edmonton"},
    {"id": 22,"utcDate": "2026-06-24T21:00:00Z","status": "SCHEDULED","group": "GROUP_K","stage": "FIRST_ROUND","homeTeam": {"shortName": "Mexico","name": "Mexico"},"awayTeam": {"shortName": "Honduras","name": "Honduras"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "Commonwealth Stadium, Edmonton"},
    {"id": 23,"utcDate": "2026-06-25T18:00:00Z","status": "SCHEDULED","group": "GROUP_L","stage": "FIRST_ROUND","homeTeam": {"shortName": "Peru","name": "Peru"},"awayTeam": {"shortName": "Qatar","name": "Qatar"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "Gillette Stadium, Boston"},
    {"id": 24,"utcDate": "2026-06-25T21:00:00Z","status": "SCHEDULED","group": "GROUP_L","stage": "FIRST_ROUND","homeTeam": {"shortName": "Austria","name": "Austria"},"awayTeam": {"shortName": "Poland","name": "Poland"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "Gillette Stadium, Boston"},
    {"id": 25,"utcDate": "2026-06-19T00:00:00Z","status": "FINISHED","group": "GROUP_A","stage": "FIRST_ROUND","homeTeam": {"shortName": "Mexico","name": "Mexico"},"awayTeam": {"shortName": "Uruguay","name": "Uruguay"},"score": {"fullTime": {"home": 1, "away": 2}},"venue": "Estadio Azteca, Mexico City"},
    {"id": 26,"utcDate": "2026-06-20T00:00:00Z","status": "FINISHED","group": "GROUP_B","stage": "FIRST_ROUND","homeTeam": {"shortName": "USA","name": "United States"},"awayTeam": {"shortName": "Portugal","name": "Portugal"},"score": {"fullTime": {"home": 1, "away": 3}},"venue": "MetLife Stadium, New York"},
    {"id": 27,"utcDate": "2026-06-21T00:00:00Z","status": "FINISHED","group": "GROUP_C","stage": "FIRST_ROUND","homeTeam": {"shortName": "Argentina","name": "Argentina"},"awayTeam": {"shortName": "Netherlands","name": "Netherlands"},"score": {"fullTime": {"home": 2, "away": 1}},"venue": "AT&T Stadium, Dallas"},
    {"id": 28,"utcDate": "2026-06-22T00:00:00Z","status": "FINISHED","group": "GROUP_D","stage": "FIRST_ROUND","homeTeam": {"shortName": "France","name": "France"},"awayTeam": {"shortName": "Denmark","name": "Denmark"},"score": {"fullTime": {"home": 2, "away": 1}},"venue": "Lincoln Financial Field, Philadelphia"},
    {"id": 29,"utcDate": "2026-06-23T00:00:00Z","status": "FINISHED","group": "GROUP_E","stage": "FIRST_ROUND","homeTeam": {"shortName": "Germany","name": "Germany"},"awayTeam": {"shortName": "Spain","name": "Spain"},"score": {"fullTime": {"home": 2, "away": 0}},"venue": "BC Place, Vancouver"},
    {"id": 30,"utcDate": "2026-06-24T00:00:00Z","status": "FINISHED","group": "GROUP_F","stage": "FIRST_ROUND","homeTeam": {"shortName": "Brazil","name": "Brazil"},"awayTeam": {"shortName": "Colombia","name": "Colombia"},"score": {"fullTime": {"home": 3, "away": 1}},"venue": "SoFi Stadium, Los Angeles"},
    {"id": 31,"utcDate": "2026-06-25T00:00:00Z","status": "FINISHED","group": "GROUP_G","stage": "FIRST_ROUND","homeTeam": {"shortName": "England","name": "England"},"awayTeam": {"shortName": "Belgium","name": "Belgium"},"score": {"fullTime": {"home": 2, "away": 0}},"venue": "NRG Stadium, Houston"},
    {"id": 32,"utcDate": "2026-06-26T00:00:00Z","status": "FINISHED","group": "GROUP_H","stage": "FIRST_ROUND","homeTeam": {"shortName": "Italy","name": "Italy"},"awayTeam": {"shortName": "Chile","name": "Chile"},"score": {"fullTime": {"home": 2, "away": 0}},"venue": "Mercedes-Benz Stadium, Atlanta"},
    {"id": 33,"utcDate": "2026-07-03T20:00:00Z","status": "SCHEDULED","stage": "KNOCKOUT_ROUND","homeTeam": {"shortName": "Mexico","name": "Mexico"},"awayTeam": {"shortName": "Brazil","name": "Brazil"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "Estadio Azteca, Mexico City"},
    {"id": 34,"utcDate": "2026-07-04T20:00:00Z","status": "SCHEDULED","stage": "KNOCKOUT_ROUND","homeTeam": {"shortName": "Argentina","name": "Argentina"},"awayTeam": {"shortName": "France","name": "France"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "AT&T Stadium, Dallas"},
    {"id": 35,"utcDate": "2026-07-09T20:00:00Z","status": "SCHEDULED","stage": "SEMIFINAL","homeTeam": {"shortName": "England","name": "England"},"awayTeam": {"shortName": "Germany","name": "Germany"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "MetLife Stadium, New York"},
    {"id": 36,"utcDate": "2026-07-19T20:00:00Z","status": "SCHEDULED","stage": "FINAL","homeTeam": {"shortName": "To Be Determined","name": "To Be Determined"},"awayTeam": {"shortName": "To Be Determined","name": "To Be Determined"},"score": {"fullTime": {"home": 0, "away": 0}},"venue": "MetLife Stadium, New York"}
  ]
}`
