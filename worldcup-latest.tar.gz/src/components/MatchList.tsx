import { Match } from '../types';
import MatchCard from './MatchCard';

interface MatchListProps {
  matches: Match[];
  title?: string;
}

export default function MatchList({ matches, title }: MatchListProps) {
  return (
    <div className="space-y-4">
      {title && (
        <h2 className="text-xl font-bold text-white flex items-center gap-2">
          <span className="w-1 h-6 bg-[#e94560] rounded-full"></span>
          {title}
        </h2>
      )}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {matches.map((match) => (
          <MatchCard key={match.id} match={match} />
        ))}
      </div>
    </div>
  );
}
