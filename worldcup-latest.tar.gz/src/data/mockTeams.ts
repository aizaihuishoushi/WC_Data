import { Team, TeamHistory } from '../types';

export const teams: Team[] = [
  { code: 'BRA', name: '巴西', logo: '🇧🇷', founded: 1914 },
  { code: 'GER', name: '德国', logo: '🇩🇪', founded: 1900 },
  { code: 'ARG', name: '阿根廷', logo: '🇦🇷', founded: 1893 },
  { code: 'FRA', name: '法国', logo: '🇫🇷', founded: 1894 },
  { code: 'ITA', name: '意大利', logo: '🇮🇹', founded: 1898 },
  { code: 'ESP', name: '西班牙', logo: '🇪🇸', founded: 1909 },
  { code: 'ENG', name: '英格兰', logo: '🏴', founded: 1863 },
  { code: 'NED', name: '荷兰', logo: '🇳🇱', founded: 1889 },
  { code: 'POR', name: '葡萄牙', logo: '🇵🇹', founded: 1914 },
  { code: 'BEL', name: '比利时', logo: '🇧🇪', founded: 1895 },
  { code: 'URU', name: '乌拉圭', logo: '🇺🇾', founded: 1900 },
  { code: 'CRO', name: '克罗地亚', logo: '🇭🇷', founded: 1912 },
  { code: 'MEX', name: '墨西哥', logo: '🇲🇽', founded: 1927 },
  { code: 'JPN', name: '日本', logo: '🇯🇵', founded: 1921 },
  { code: 'KOR', name: '韩国', logo: '🇰🇷', founded: 1928 },
  { code: 'USA', name: '美国', logo: '🇺🇸', founded: 1913 },
  { code: 'SEN', name: '塞内加尔', logo: '🇸🇳', founded: 1960 },
  { code: 'MAR', name: '摩洛哥', logo: '🇲🇦', founded: 1956 },
  { code: 'SUI', name: '瑞士', logo: '🇨🇭', founded: 1895 },
  { code: 'POL', name: '波兰', logo: '🇵🇱', founded: 1919 },
  { code: 'AUS', name: '澳大利亚', logo: '🇦🇺', founded: 1961 },
  { code: 'DEN', name: '丹麦', logo: '🇩🇰', founded: 1889 },
  { code: 'SWE', name: '瑞典', logo: '🇸🇪', founded: 1904 },
  { code: 'WAL', name: '威尔士', logo: '🏴', founded: 1876 },
  { code: 'ECU', name: '厄瓜多尔', logo: '🇪🇨', founded: 1924 },
  { code: 'QAT', name: '卡塔尔', logo: '🇶🇦', founded: 1974 },
  { code: 'KSA', name: '沙特阿拉伯', logo: '🇸🇦', founded: 1956 },
  { code: 'IRN', name: '伊朗', logo: '🇮🇷', founded: 1920 },
  { code: 'SRB', name: '塞尔维亚', logo: '🇷🇸', founded: 1919 },
  { code: 'GHA', name: '加纳', logo: '🇬🇭', founded: 1920 },
  { code: 'CMR', name: '喀麦隆', logo: '🇨🇲', founded: 1958 },
  { code: 'NGA', name: '尼日利亚', logo: '🇳🇬', founded: 1940 },
  { code: 'COL', name: '哥伦比亚', logo: '🇨🇴', founded: 1924 },
  { code: 'CHI', name: '智利', logo: '🇨🇱', founded: 1895 },
  { code: 'PER', name: '秘鲁', logo: '🇵🇪', founded: 1922 },
  { code: 'PAR', name: '巴拉圭', logo: '🇵🇾', founded: 1906 },
  { code: 'TUN', name: '突尼斯', logo: '🇹🇳', founded: 1957 },
  { code: 'CAN', name: '加拿大', logo: '🇨🇦', founded: 1912 },
  { code: 'CRI', name: '哥斯达黎加', logo: '🇨🇷', founded: 1921 },
];

export const teamHistories: Record<string, TeamHistory> = {
  BRA: {
    teamCode: 'BRA',
    participations: [
      {
        year: 2022,
        stage: '八强',
        matches: [
          { opponent: '韩国', score: '4-1', result: 'win', goalsFor: 4, goalsAgainst: 1 },
          { opponent: '克罗地亚', score: '1-1(点球2-4)', result: 'loss', goalsFor: 1, goalsAgainst: 1 },
        ],
      },
      {
        year: 2018,
        stage: '八强',
        matches: [
          { opponent: '瑞士', score: '1-1', result: 'draw', goalsFor: 1, goalsAgainst: 1 },
          { opponent: '墨西哥', score: '2-0', result: 'win', goalsFor: 2, goalsAgainst: 0 },
          { opponent: '比利时', score: '2-1', result: 'win', goalsFor: 2, goalsAgainst: 1 },
          { opponent: '法国', score: '1-2', result: 'loss', goalsFor: 1, goalsAgainst: 2 },
        ],
      },
      {
        year: 2014,
        stage: '四强',
        matches: [
          { opponent: '克罗地亚', score: '3-1', result: 'win', goalsFor: 3, goalsAgainst: 1 },
          { opponent: '喀麦隆', score: '4-1', result: 'win', goalsFor: 4, goalsAgainst: 1 },
          { opponent: '智利', score: '1-1(点球3-2)', result: 'win', goalsFor: 1, goalsAgainst: 1 },
          { opponent: '哥伦比亚', score: '2-1', result: 'win', goalsFor: 2, goalsAgainst: 1 },
          { opponent: '德国', score: '1-7', result: 'loss', goalsFor: 1, goalsAgainst: 7 },
        ],
      },
      {
        year: 2002,
        stage: '冠军',
        matches: [
          { opponent: '中国', score: '4-0', result: 'win', goalsFor: 4, goalsAgainst: 0 },
          { opponent: '比利时', score: '2-0', result: 'win', goalsFor: 2, goalsAgainst: 0 },
          { opponent: '土耳其', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
          { opponent: '比利时', score: '2-0', result: 'win', goalsFor: 2, goalsAgainst: 0 },
          { opponent: '英格兰', score: '2-1', result: 'win', goalsFor: 2, goalsAgainst: 1 },
          { opponent: '土耳其', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
          { opponent: '德国', score: '2-0', result: 'win', goalsFor: 2, goalsAgainst: 0 },
        ],
      },
      {
        year: 1994,
        stage: '冠军',
        matches: [
          { opponent: '俄罗斯', score: '2-0', result: 'win', goalsFor: 2, goalsAgainst: 0 },
          { opponent: '瑞典', score: '1-1', result: 'draw', goalsFor: 1, goalsAgainst: 1 },
          { opponent: '喀麦隆', score: '2-0', result: 'win', goalsFor: 2, goalsAgainst: 0 },
          { opponent: '美国', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
          { opponent: '荷兰', score: '3-2', result: 'win', goalsFor: 3, goalsAgainst: 2 },
          { opponent: '瑞典', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
          { opponent: '意大利', score: '0-0(点球3-2)', result: 'win', goalsFor: 0, goalsAgainst: 0 },
        ],
      },
    ],
    stats: {
      totalParticipations: 22,
      totalMatches: 113,
      wins: 73,
      draws: 19,
      losses: 21,
      totalGoals: 237,
    },
  },
  GER: {
    teamCode: 'GER',
    participations: [
      {
        year: 2022,
        stage: '小组赛',
        matches: [
          { opponent: '日本', score: '1-2', result: 'loss', goalsFor: 1, goalsAgainst: 2 },
          { opponent: '西班牙', score: '1-2', result: 'loss', goalsFor: 1, goalsAgainst: 2 },
          { opponent: '哥斯达黎加', score: '4-2', result: 'win', goalsFor: 4, goalsAgainst: 2 },
        ],
      },
      {
        year: 2018,
        stage: '小组赛',
        matches: [
          { opponent: '墨西哥', score: '0-1', result: 'loss', goalsFor: 0, goalsAgainst: 1 },
          { opponent: '瑞典', score: '2-1', result: 'win', goalsFor: 2, goalsAgainst: 1 },
          { opponent: '韩国', score: '2-0', result: 'win', goalsFor: 2, goalsAgainst: 0 },
        ],
      },
      {
        year: 2014,
        stage: '冠军',
        matches: [
          { opponent: '葡萄牙', score: '4-0', result: 'win', goalsFor: 4, goalsAgainst: 0 },
          { opponent: '加纳', score: '2-2', result: 'draw', goalsFor: 2, goalsAgainst: 2 },
          { opponent: '美国', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
          { opponent: '阿尔及利亚', score: '2-1', result: 'win', goalsFor: 2, goalsAgainst: 1 },
          { opponent: '法国', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
          { opponent: '巴西', score: '7-1', result: 'win', goalsFor: 7, goalsAgainst: 1 },
          { opponent: '阿根廷', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
        ],
      },
    ],
    stats: {
      totalParticipations: 20,
      totalMatches: 109,
      wins: 67,
      draws: 20,
      losses: 22,
      totalGoals: 226,
    },
  },
  ARG: {
    teamCode: 'ARG',
    participations: [
      {
        year: 2022,
        stage: '冠军',
        matches: [
          { opponent: '沙特阿拉伯', score: '1-2', result: 'loss', goalsFor: 1, goalsAgainst: 2 },
          { opponent: '墨西哥', score: '2-0', result: 'win', goalsFor: 2, goalsAgainst: 0 },
          { opponent: '波兰', score: '2-0', result: 'win', goalsFor: 2, goalsAgainst: 0 },
          { opponent: '澳大利亚', score: '2-1', result: 'win', goalsFor: 2, goalsAgainst: 1 },
          { opponent: '荷兰', score: '2-2(点球3-4)', result: 'win', goalsFor: 2, goalsAgainst: 2 },
          { opponent: '克罗地亚', score: '3-0', result: 'win', goalsFor: 3, goalsAgainst: 0 },
          { opponent: '法国', score: '3-3(点球4-2)', result: 'win', goalsFor: 3, goalsAgainst: 3 },
        ],
      },
      {
        year: 2018,
        stage: '十六强',
        matches: [
          { opponent: '冰岛', score: '1-1', result: 'draw', goalsFor: 1, goalsAgainst: 1 },
          { opponent: '克罗地亚', score: '0-3', result: 'loss', goalsFor: 0, goalsAgainst: 3 },
          { opponent: '尼日利亚', score: '2-1', result: 'win', goalsFor: 2, goalsAgainst: 1 },
          { opponent: '法国', score: '3-4', result: 'loss', goalsFor: 3, goalsAgainst: 4 },
        ],
      },
      {
        year: 2014,
        stage: '亚军',
        matches: [
          { opponent: '波黑', score: '2-1', result: 'win', goalsFor: 2, goalsAgainst: 1 },
          { opponent: '伊朗', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
          { opponent: '尼日利亚', score: '3-2', result: 'win', goalsFor: 3, goalsAgainst: 2 },
          { opponent: '瑞士', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
          { opponent: '比利时', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
          { opponent: '荷兰', score: '0-0(点球4-2)', result: 'win', goalsFor: 0, goalsAgainst: 0 },
          { opponent: '德国', score: '0-1', result: 'loss', goalsFor: 0, goalsAgainst: 1 },
        ],
      },
    ],
    stats: {
      totalParticipations: 18,
      totalMatches: 85,
      wins: 48,
      draws: 17,
      losses: 20,
      totalGoals: 148,
    },
  },
  FRA: {
    teamCode: 'FRA',
    participations: [
      {
        year: 2022,
        stage: '亚军',
        matches: [
          { opponent: '澳大利亚', score: '4-1', result: 'win', goalsFor: 4, goalsAgainst: 1 },
          { opponent: '丹麦', score: '2-1', result: 'win', goalsFor: 2, goalsAgainst: 1 },
          { opponent: '突尼斯', score: '0-1', result: 'loss', goalsFor: 0, goalsAgainst: 1 },
          { opponent: '波兰', score: '3-1', result: 'win', goalsFor: 3, goalsAgainst: 1 },
          { opponent: '英格兰', score: '2-1', result: 'win', goalsFor: 2, goalsAgainst: 1 },
          { opponent: '摩洛哥', score: '2-0', result: 'win', goalsFor: 2, goalsAgainst: 0 },
          { opponent: '阿根廷', score: '3-3(点球2-4)', result: 'loss', goalsFor: 3, goalsAgainst: 3 },
        ],
      },
      {
        year: 2018,
        stage: '冠军',
        matches: [
          { opponent: '澳大利亚', score: '2-1', result: 'win', goalsFor: 2, goalsAgainst: 1 },
          { opponent: '秘鲁', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
          { opponent: '丹麦', score: '0-0', result: 'draw', goalsFor: 0, goalsAgainst: 0 },
          { opponent: '阿根廷', score: '4-3', result: 'win', goalsFor: 4, goalsAgainst: 3 },
          { opponent: '乌拉圭', score: '2-0', result: 'win', goalsFor: 2, goalsAgainst: 0 },
          { opponent: '比利时', score: '1-0', result: 'win', goalsFor: 1, goalsAgainst: 0 },
          { opponent: '克罗地亚', score: '4-2', result: 'win', goalsFor: 4, goalsAgainst: 2 },
        ],
      },
    ],
    stats: {
      totalParticipations: 16,
      totalMatches: 69,
      wins: 39,
      draws: 13,
      losses: 17,
      totalGoals: 129,
    },
  },
};

export const getTeamByCode = (code: string): Team | undefined => {
  return teams.find(t => t.code === code);
};

export const getTeamHistory = (code: string): TeamHistory | undefined => {
  return teamHistories[code];
};
