import { Match, Team } from '../types';

export async function fetchLiveMatches(): Promise<Match[]> {
  try {
    console.log('[数据] 正在请求 /api/matches (通过服务器代理)...');

    const response = await fetch('/api/matches', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      },
    });

    console.log('[数据] 响应状态:', response.status, response.statusText);

    if (!response.ok) {
      const errorText = await response.text();
      console.error('[数据] 请求失败:', errorText);
      return getMockMatches();
    }

    const data = await response.json();
    console.log('[数据] 返回数据，包含', data.matches?.length || 0, '场比赛');

    return transformMatches(data.matches);
  } catch (error) {
    console.error('[数据] 请求失败:', error);
    return getMockMatches();
  }
}

// 将 API 的原始 stage 字段解析为业务语义
function parseStage(rawStage: string): Match['stage'] {
  if (!rawStage) return 'group';
  const s = rawStage.toUpperCase();

  if (s.includes('FIRST_ROUND') || s.includes('GROUP') || s === 'FIRST_ROUND' || s.includes('SECOND') || s.includes('THIRD')) {
    return 'group';
  }
  if (s.includes('ROUND_OF_16') || s.includes('RO16') || s.includes('1/8') || s.includes('EIGHTH')) {
    return 'round16';
  }
  if (s.includes('QUARTER') || s.includes('QF') || s.includes('1/4')) {
    return 'quarter';
  }
  if (s.includes('SEMI') || s.includes('SF')) {
    return 'semi';
  }
  if (s === 'FINAL' || s.includes('FINAL')) {
    return 'final';
  }
  if (s.includes('KNOCKOUT')) {
    return 'knockout';
  }
  return 'group';
}

function transformMatches(apiMatches: any[]): Match[] {
  if (!apiMatches || apiMatches.length === 0) {
    return getMockMatches();
  }

  return apiMatches.map((match, index) => {
    const rawStage = (match.stage || '').toUpperCase();
    const parsedStage = parseStage(rawStage);
    const apiGroup = match.group?.replace('GROUP_', '') || undefined;

    // 解析比分
    let homeScore = 0, awayScore = 0;
    if (match.score?.fullTime) {
      homeScore = match.score.fullTime.home ?? 0;
      awayScore = match.score.fullTime.away ?? 0;
    }
    if (match.score?.extraTime) {
      homeScore = match.score.extraTime.home ?? homeScore;
      awayScore = match.score.extraTime.away ?? awayScore;
    }
    if (match.score?.penalties) {
      homeScore = match.score.penalties.home ?? homeScore;
      awayScore = match.score.penalties.away ?? awayScore;
    }

    return {
      id: match.id?.toString() || String(index),
      date: match.utcDate?.split('T')[0] || new Date().toISOString().split('T')[0],
      time: match.utcDate?.split('T')[1]?.substring(0, 5) || '00:00',
      stage: parsedStage,
      rawStage: rawStage,
      group: apiGroup,
      homeTeam: transformTeam(match.homeTeam, 'home'),
      awayTeam: transformTeam(match.awayTeam, 'away'),
      homeScore,
      awayScore,
      status: transformStatus(match.status),
      venue: match.venue || '世界杯赛场',
    };
  });
}

function transformTeam(apiTeam: any, position: string): Team {
  const shortName = apiTeam?.shortName || apiTeam?.name || (position === 'home' ? '主队' : '客队');
  const fullName = apiTeam?.name || shortName;

  return {
    code: shortName.substring(0, 3).toUpperCase(),
    name: fullName,
    logo: getFlagEmoji(shortName),
    founded: 1900,
  };
}

function transformStatus(status: string): Match['status'] {
  switch (status) {
    case 'IN_PLAY':
    case 'PAUSED':
    case 'LIVE':
      return 'live';
    case 'FINISHED':
    case 'AWARDED':
      return 'finished';
    case 'SCHEDULED':
    case 'TIMED':
    case 'POSTPONED':
      return 'upcoming';
    default:
      return 'upcoming';
  }
}

function getFlagEmoji(teamName: string): string {
  if (!teamName) return '⚽';

  const flags: Record<string, string> = {
    'BRAZIL': '🇧🇷', 'BRA': '🇧🇷', 'BR': '🇧🇷',
    'GERMANY': '🇩🇪', 'GER': '🇩🇪', 'DE': '🇩🇪',
    'ARGENTINA': '🇦🇷', 'ARG': '🇦🇷', 'AR': '🇦🇷',
    'FRANCE': '🇫🇷', 'FRA': '🇫🇷', 'FR': '🇫🇷',
    'SPAIN': '🇪🇸', 'ESP': '🇪🇸', 'ES': '🇪🇸',
    'ENGLAND': '🏴', 'ENG': '🏴',
    'NETHERLANDS': '🇳🇱', 'NED': '🇳🇱', 'NLD': '🇳🇱',
    'PORTUGAL': '🇵🇹', 'POR': '🇵🇹', 'PT': '🇵🇹',
    'BELGIUM': '🇧🇪', 'BEL': '🇧🇪', 'BE': '🇧🇪',
    'URUGUAY': '🇺🇾', 'URU': '🇺🇾', 'UY': '🇺🇾',
    'CROATIA': '🇭🇷', 'CRO': '🇭🇷', 'HR': '🇭🇷',
    'MEXICO': '🇲🇽', 'MEX': '🇲🇽', 'MX': '🇲🇽',
    'JAPAN': '🇯🇵', 'JPN': '🇯🇵', 'JP': '🇯🇵',
    'KOREA REPUBLIC': '🇰🇷', 'KOR': '🇰🇷', 'KR': '🇰🇷', 'SOUTH KOREA': '🇰🇷',
    'UNITED STATES': '🇺🇸', 'USA': '🇺🇸', 'US': '🇺🇸',
    'SENEGAL': '🇸🇳', 'SEN': '🇸🇳',
    'MOROCCO': '🇲🇦', 'MAR': '🇲🇦',
    'SWITZERLAND': '🇨🇭', 'SUI': '🇨🇭', 'CHE': '🇨🇭',
    'POLAND': '🇵🇱', 'POL': '🇵🇱', 'PL': '🇵🇱',
    'AUSTRALIA': '🇦🇺', 'AUS': '🇦🇺', 'AU': '🇦🇺',
    'DENMARK': '🇩🇰', 'DEN': '🇩🇰', 'DK': '🇩🇰',
    'WALES': '🏴', 'WAL': '🏴',
    'ECUADOR': '🇪🇨', 'ECU': '🇪🇨', 'EC': '🇪🇨',
    'QATAR': '🇶🇦', 'QAT': '🇶🇦',
    'SAUDI ARABIA': '🇸🇦', 'KSA': '🇸🇦',
    'IR IRAN': '🇮🇷', 'IRAN': '🇮🇷', 'IRN': '🇮🇷',
    'TUNISIA': '🇹🇳', 'TUN': '🇹🇳',
    'CANADA': '🇨🇦', 'CAN': '🇨🇦',
    'COSTA RICA': '🇨🇷', 'CRC': '🇨🇷', 'CRI': '🇨🇷',
    'GHANA': '🇬🇭', 'GHA': '🇬🇭',
    'CMR': '🇨🇲', 'CAMEROON': '🇨🇲',
    'COLOMBIA': '🇨🇴', 'COL': '🇨🇴',
    'ITALY': '🇮🇹', 'ITA': '🇮🇹',
    'CHILE': '🇨🇱', 'CHI': '🇨🇱',
    'PANAMA': '🇵🇦', 'PAN': '🇵🇦',
    'NORWAY': '🇳🇴', 'NOR': '🇳🇴',
    'NEW ZEALAND': '🇳🇿', 'NZL': '🇳🇿',
    'EGYPT': '🇪🇬', 'EGY': '🇪🇬',
    'SERBIA': '🇷🇸', 'SRB': '🇷🇸',
    'SWEDEN': '🇸🇪', 'SWE': '🇸🇪',
    'IVORY COAST': '🇨🇮', 'CIV': '🇨🇮', 'CÔTE D\'IVOIRE': '🇨🇮',
    'HONDURAS': '🇭🇳', 'HON': '🇭🇳',
    'PERU': '🇵🇪', 'PER': '🇵🇪',
    'AUSTRIA': '🇦🇹', 'AUT': '🇦🇹',
  };

  const upperName = teamName.toUpperCase();
  for (const [key, emoji] of Object.entries(flags)) {
    if (upperName.includes(key)) return emoji;
  }
  return '⚽';
}

export function getMockMatches(): Match[] {
  return [
    {
      id: '1', date: '2026-06-14', time: '18:00', stage: 'group', rawStage: 'FIRST_ROUND', group: 'A',
      homeTeam: { code: 'MEX', name: 'Mexico', logo: '🇲🇽', founded: 1927 },
      awayTeam: { code: 'CAN', name: 'Canada', logo: '🇨🇦', founded: 1912 },
      homeScore: 2, awayScore: 1, status: 'finished', venue: 'Estadio Azteca, Mexico City',
    },
    {
      id: '2', date: '2026-06-14', time: '21:00', stage: 'group', rawStage: 'FIRST_ROUND', group: 'A',
      homeTeam: { code: 'URU', name: 'Uruguay', logo: '🇺🇾', founded: 1900 },
      awayTeam: { code: 'KOR', name: 'Korea Republic', logo: '🇰🇷', founded: 1928 },
      homeScore: 1, awayScore: 0, status: 'finished', venue: 'Estadio Azteca, Mexico City',
    },
    {
      id: '3', date: '2026-06-15', time: '18:00', stage: 'group', rawStage: 'FIRST_ROUND', group: 'B',
      homeTeam: { code: 'USA', name: 'United States', logo: '🇺🇸', founded: 1913 },
      awayTeam: { code: 'ECU', name: 'Ecuador', logo: '🇪🇨', founded: 1925 },
      homeScore: 2, awayScore: 0, status: 'finished', venue: 'MetLife Stadium, New York',
    },
    {
      id: '4', date: '2026-06-15', time: '21:00', stage: 'group', rawStage: 'FIRST_ROUND', group: 'B',
      homeTeam: { code: 'POR', name: 'Portugal', logo: '🇵🇹', founded: 1914 },
      awayTeam: { code: 'GHA', name: 'Ghana', logo: '🇬🇭', founded: 1957 },
      homeScore: 3, awayScore: 1, status: 'finished', venue: 'MetLife Stadium, New York',
    },
    {
      id: '5', date: '2026-06-16', time: '18:00', stage: 'group', rawStage: 'FIRST_ROUND', group: 'C',
      homeTeam: { code: 'ARG', name: 'Argentina', logo: '🇦🇷', founded: 1893 },
      awayTeam: { code: 'KSA', name: 'Saudi Arabia', logo: '🇸🇦', founded: 1956 },
      homeScore: 3, awayScore: 0, status: 'finished', venue: 'AT&T Stadium, Dallas',
    },
    {
      id: '6', date: '2026-06-16', time: '21:00', stage: 'group', rawStage: 'FIRST_ROUND', group: 'C',
      homeTeam: { code: 'NED', name: 'Netherlands', logo: '🇳🇱', founded: 1889 },
      awayTeam: { code: 'SEN', name: 'Senegal', logo: '🇸🇳', founded: 1960 },
      homeScore: 2, awayScore: 2, status: 'finished', venue: 'AT&T Stadium, Dallas',
    },
    {
      id: '7', date: '2026-06-17', time: '18:00', stage: 'group', rawStage: 'FIRST_ROUND', group: 'D',
      homeTeam: { code: 'FRA', name: 'France', logo: '🇫🇷', founded: 1904 },
      awayTeam: { code: 'AUS', name: 'Australia', logo: '🇦🇺', founded: 1961 },
      homeScore: 4, awayScore: 1, status: 'finished', venue: 'Lincoln Financial Field, Philadelphia',
    },
    {
      id: '8', date: '2026-06-17', time: '21:00', stage: 'group', rawStage: 'FIRST_ROUND', group: 'D',
      homeTeam: { code: 'DEN', name: 'Denmark', logo: '🇩🇰', founded: 1889 },
      awayTeam: { code: 'TUN', name: 'Tunisia', logo: '🇹🇳', founded: 1957 },
      homeScore: 2, awayScore: 0, status: 'finished', venue: 'Lincoln Financial Field, Philadelphia',
    },
    {
      id: '9', date: '2026-06-18', time: '18:00', stage: 'group', rawStage: 'FIRST_ROUND', group: 'E',
      homeTeam: { code: 'GER', name: 'Germany', logo: '🇩🇪', founded: 1900 },
      awayTeam: { code: 'JPN', name: 'Japan', logo: '🇯🇵', founded: 1921 },
      homeScore: 1, awayScore: 2, status: 'live', venue: 'BC Place, Vancouver',
    },
    {
      id: '10', date: '2026-06-18', time: '21:00', stage: 'group', rawStage: 'FIRST_ROUND', group: 'E',
      homeTeam: { code: 'ESP', name: 'Spain', logo: '🇪🇸', founded: 1909 },
      awayTeam: { code: 'CRC', name: 'Costa Rica', logo: '🇨🇷', founded: 1921 },
      homeScore: 0, awayScore: 0, status: 'upcoming', venue: 'BC Place, Vancouver',
    },
  ];
}
