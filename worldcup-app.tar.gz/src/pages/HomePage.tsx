import { useState } from 'react';
import { useAppStore } from '../store/appStore';
import MatchList from '../components/MatchList';
import { matches as allMatches } from '../data/mockMatches';
import { Radio, Calendar, Filter } from 'lucide-react';

type TabType = 'live' | 'schedule';

const groups = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'];

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<TabType>('live');
  const { activeGroup, setActiveGroup } = useAppStore();

  const liveMatches = allMatches.filter((m) => m.status === 'live');
  const upcomingMatches = allMatches.filter((m) => m.status === 'upcoming');
  const groupMatches = allMatches.filter(
    (m) => m.stage === 'group' && m.group === activeGroup
  );

  return (
    <div className="min-h-screen pb-24">
      <header className="bg-gradient-to-r from-[#1a1a2e] to-[#16213e] border-b border-white/5 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-gradient-to-br from-[#e94560] to-[#0f3460] flex items-center justify-center">
              <span className="text-2xl">🏆</span>
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">世界杯 2026</h1>
              <p className="text-gray-400 text-sm">FIFA World Cup Qatar 2026</p>
            </div>
          </div>

          <div className="flex gap-2">
            <button
              onClick={() => setActiveTab('live')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                activeTab === 'live'
                  ? 'bg-[#e94560] text-white'
                  : 'bg-white/5 text-gray-400 hover:bg-white/10'
              }`}
            >
              <Radio className="w-4 h-4" />
              赛事
            </button>
            <button
              onClick={() => setActiveTab('schedule')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all ${
                activeTab === 'schedule'
                  ? 'bg-[#e94560] text-white'
                  : 'bg-white/5 text-gray-400 hover:bg-white/10'
              }`}
            >
              <Calendar className="w-4 h-4" />
              赛程
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6">
        {activeTab === 'live' && (
          <div className="space-y-8">
            {liveMatches.length > 0 && (
              <section>
                <MatchList
                  matches={liveMatches}
                  title={`正在直播 (${liveMatches.length})`}
                />
              </section>
            )}

            <section>
              <h2 className="text-xl font-bold text-white flex items-center gap-2 mb-4">
                <span className="w-1 h-6 bg-[#e94560] rounded-full"></span>
                即将开始 ({upcomingMatches.length})
              </h2>
              <MatchList matches={upcomingMatches.slice(0, 4)} />
            </section>
          </div>
        )}

        {activeTab === 'schedule' && (
          <div className="space-y-6">
            <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-hide">
              <Filter className="w-4 h-4 text-gray-400 flex-shrink-0" />
              <div className="flex gap-2">
                {groups.map((group) => (
                  <button
                    key={group}
                    onClick={() => setActiveGroup(group)}
                    className={`px-4 py-2 rounded-lg font-medium transition-all flex-shrink-0 ${
                      activeGroup === group
                        ? 'bg-[#e94560] text-white'
                        : 'bg-white/5 text-gray-400 hover:bg-white/10'
                    }`}
                  >
                    小组 {group}
                  </button>
                ))}
              </div>
            </div>

            <MatchList
              matches={groupMatches}
              title={`小组 ${activeGroup} 赛程`}
            />
          </div>
        )}
      </main>
    </div>
  );
}
