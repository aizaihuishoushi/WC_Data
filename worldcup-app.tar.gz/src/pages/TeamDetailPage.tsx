import { useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { useAppStore, getAllTeams } from '../store/appStore';
import { getTeamHistory } from '../data/mockTeams';
import TeamInfo from '../components/TeamInfo';
import TeamStats from '../components/TeamStats';
import TeamHistory from '../components/TeamHistory';
import { ArrowLeft } from 'lucide-react';

export default function TeamDetailPage() {
  const { teamCode } = useParams<{ teamCode: string }>();
  const { teamHistory, fetchTeamHistory } = useAppStore();

  const teams = getAllTeams();
  const team = teams.find((t) => t.code === teamCode);

  useEffect(() => {
    if (teamCode) {
      fetchTeamHistory(teamCode);
    }
  }, [teamCode, fetchTeamHistory]);

  if (!team) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">球队未找到</h1>
          <Link
            to="/"
            className="text-[#e94560] hover:underline flex items-center gap-2 justify-center"
          >
            <ArrowLeft className="w-4 h-4" />
            返回首页
          </Link>
        </div>
      </div>
    );
  }

  const history = getTeamHistory(team.code);

  return (
    <div className="min-h-screen pb-24">
      <header className="bg-gradient-to-r from-[#1a1a2e] to-[#16213e] border-b border-white/5 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto px-4 py-4">
          <Link
            to="/"
            className="inline-flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span>返回</span>
          </Link>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        <TeamInfo
          team={team}
          participationCount={history?.stats.totalParticipations}
        />

        {history && <TeamStats stats={history.stats} />}

        {history && <TeamHistory history={history} />}
      </main>
    </div>
  );
}
