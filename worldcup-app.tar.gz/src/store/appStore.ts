import { create } from 'zustand';
import { Match, Team, TeamHistory } from '../types';
import { matches as mockMatches } from '../data/mockMatches';
import { teams, getTeamHistory } from '../data/mockTeams';

interface AppState {
  matches: Match[];
  loading: boolean;
  selectedTeam: Team | null;
  teamHistory: TeamHistory | null;
  activeGroup: string;
  setActiveGroup: (group: string) => void;
  setSelectedTeam: (team: Team | null) => void;
  fetchTeamHistory: (teamCode: string) => void;
}

export const useAppStore = create<AppState>((set) => ({
  matches: mockMatches,
  loading: false,
  selectedTeam: null,
  teamHistory: null,
  activeGroup: 'A',
  setActiveGroup: (group: string) => set({ activeGroup: group }),
  setSelectedTeam: (team: Team | null) => set({ selectedTeam: team }),
  fetchTeamHistory: (teamCode: string) => {
    const history = getTeamHistory(teamCode);
    set({ teamHistory: history || null });
  },
}));

export const getAllTeams = () => teams;
